# SIEGE 2D - itch.io + Firebase (matchmaking + skill ratings)

Your Firebase project (siege2d2) is already baked into public/index.html.

## One-time Firebase setup (2 minutes)
1. Authentication -> Sign-in method -> enable **Anonymous**.   (ratings need an account id; players never see a login)
2. Realtime Database -> Rules -> paste database.rules.json -> Publish. (re-publish it whenever it changes; spectating needs the new `live` node)
3. (Only if sign-in fails) Google Cloud Console -> APIs & Services -> Credentials -> your browser API key:
   it must allow "Identity Toolkit API" and "Token Service API", and have no HTTP-referrer restriction that blocks itch.io.

## Upload to itch.io
Upload siege2d-itch.zip -> Kind of project: HTML -> tick "played in the browser" -> viewport 1280x768, enable fullscreen.
Test it first by opening public/index.html from a local web server (e.g. `npx serve public`) in two browser windows.

## How ranked works
- Quick Match puts you in the queue for your team size (1v1, 2v2 or 3v3) tagged with your rating (new players start at 1000).
- The longest-waiting player searches for opponents within a rating range that starts at +/-100 and widens by 25 per second,
  so matches are close at busy times and nobody waits much more than ~40s.
- In 2v2 the four players are split by rating (strongest + weakest vs the middle two); in 3v3 the six are snake-split (1st,4th,5th vs 2nd,3rd,6th). Bots mode also offers 5v5. IMPORTANT: re-publish database.rules.json (it now allows the m3 queue).
- After a ranked match each player's browser applies an Elo update (K=32, max +/-30) to ratings/<uid>.
  Room-code games are unranked. The Leaderboard button shows the top 10.
- Ratings are tied to the browser's anonymous account (cleared storage = new account). Add Google/email sign-in later to make them permanent.

## Limits
- Ratings are written by clients. The rules cap each update to +/-35 and require games+1, which stops casual tampering,
  but a determined cheater could still farm points. For true authority use a Cloud Function (needs the Blaze plan).
- Hits are decided by the victim's client; no anti-cheat.
- Spectate: Online menu -> Spectate. 'Live matches' lists running public games (Firebase build + updated rules); 'Watch room code' works anywhere. Left/Right switch player, Esc leaves.
